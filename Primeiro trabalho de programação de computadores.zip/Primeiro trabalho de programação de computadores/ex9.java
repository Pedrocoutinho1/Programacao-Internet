import java.util.Scanner;
class ex9{


    public static void main(String[]args){

        Scanner s = new Scanner(System.in);

        //declarando variáveis

      
        //pedindo numeros:

       
        //calculos

       

        //resultados

       
    }


}
