import java.util.Scanner;

class ex2{
   
    public static void main(String[]args){


    Scanner s = new Scanner(System.in);

    //declaração das variáveis

    String nome;
    int idade;
    String genero;
    String cor;
    boolean esporte;

    //campos de entrada

    System.out.println("Insira seu Nome: ");
    nome = s.nextLine();
    System.out.println("\n");

    System.out.println("Insira sua Idade: ");
    idade = s.nextInt();
    System.out.println("\n");

    System.out.println("Insira seu Gênero: ");
    genero = s.next();
    System.out.println("\n");

    System.out.println("Insira sua cor favorita: ");
    cor = s.next();
    System.out.println("\n");
    s.nextLine();

    System.out.println("Insira se pratica algum esporte, e qual: ");
    esporte = s.nextBoolean();
    System.out.println("\n");

    //resultados

    System.out.println("Resultados: " + "\n");

    System.out.println("Nome: " + nome);
    
    System.out.println("Idade: " + idade);

    System.out.println("Genero: " + genero);

    System.out.println("Cor Favorita: " + cor);

    System.out.println("Pratica algum esporte? qual?: " + esporte);


}
}

//deu certo, parcial só não terminei o boolean, o do esporte, qualquer coisa usa string ao invéz de boolean