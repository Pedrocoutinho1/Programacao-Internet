import java.util.Scanner;
class ex4{


    public static void main(String[]args){

        Scanner s = new Scanner(System.in);

        //declarando variáveis

        int A;
        int B;
        int maior;
        int menor;
        int igual;

        //pedindo numeros:

        System.out.println("Insira os valores numeros inteiros: " + "\n");
        System.out.println("Primeiro valor: ");
        A = s.nextInt();
        System.out.println("Segundo valor: ");
        B = s.nextInt();

        //calculos

        maior = A > B;
        menor = A < B;
        igual = A = B;

        //resultados

        System.out.println("\n");
        System.out.println("Resultados: " + "\n");
        System.out.println("É maior: " + maior);
        System.out.println("É menor: " + menor);
        System.out.println("igual: " + igual);
    }


}
