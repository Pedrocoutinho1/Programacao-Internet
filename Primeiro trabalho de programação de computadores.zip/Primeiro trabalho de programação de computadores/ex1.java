import java.util.Scanner;


class ex1{
   
    public static void main(String[]args){

    //criar variáveis

    Scanner s = new Scanner(System.in);

    double notaFinal;

   System.out.println("Informe sua nota final: ");
   notaFinal = s.nextDouble();


   //calculos
   //isso já é tipo um boolean porque tem verdadeiro ou falso:
   if(notaFinal < 6 && notaFinal > 4){
    //verdade (true)
    System.out.println("Precisa fazer prova substitutiva.");
   }else if (notaFinal >= 6)
   {//verdade (true)
    System.out.println("Aprovado.");   

   }else
   {//falso (false)
    System.out.println("Reprovado.");

    }


    //deu certo







    }
}
