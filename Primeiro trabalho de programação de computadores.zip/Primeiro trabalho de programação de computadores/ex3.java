import java.util.Scanner;
class ex3{


    public static void main(String[]args){

        Scanner s = new Scanner(System.in);

        //declarando variáveis

        int A;
        int B;

        int soma;
        int subtracao;
        int multiplicacao;
        double divisao; 
        double resto_divisao; 

        //pedindo numeros:

        System.out.println("Insira os valores dos numeros para fazer as operacoes: " + "\n");
        System.out.println("Primeiro valor: ");
        A = s.nextInt();
        System.out.println("Segundo valor: ");
        B = s.nextInt();

        //calculos

        soma = A + B;
        subtracao = A - B;
        multiplicacao = A * B;
        divisao = A / B;
        resto_divisao = A % B;

        //resultados

        System.out.println("\n");
        System.out.println("Resultados: " + "\n");
        System.out.println("Soma: " + soma);
        System.out.println("Subtracao: " + subtracao);
        System.out.println("Multiplicacao: " + multiplicacao);
        System.out.println("Divisao: " + divisao);
        System.out.println("Resto da divisao: " + resto_divisao + "\n");
    }


}

//deu certo
