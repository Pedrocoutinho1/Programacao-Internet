let campoAno = document.querySelector("#campoAno");
let campoValorTabela = document.querySelector("#campoValorTabela");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let ano = parseFloat(campoAno.value.replace(",","."));
    let valor = parseFloat(campoValorTabela.value.replace(",","."));
    if (isNaN(ano) || isNaN(valor) || ano <= 0 || valor <= 0){ resultado.innerHTML = "Por favor, insira um ano e valor v&aacute;lidos.";
        return;
    }

    let taxa;
  if (ano < 1990) {
    taxa = 0.01;
  } else {
    taxa = 0.015;
  }

  const imposto = valor * taxa;
  resultado.textContent = `Imposto a pagar: R$ ${imposto.toFixed(2)}`;
}
);