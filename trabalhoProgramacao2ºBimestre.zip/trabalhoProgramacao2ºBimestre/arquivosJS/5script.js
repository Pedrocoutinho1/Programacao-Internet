let CampoSaldo = document.querySelector("#campoSaldo");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let saldo = parseFloat(campoSaldo.value.replace(",","."));
    if (isNaN(saldo) || saldo <0){ resultado.innerHTML = "Por favor, insira um saldo v&aacute;lido.";
        return;
    }

     let percentual = 0;

  if (saldo <= 200) {
    percentual = 0;
  } else if (saldo <= 400) {
    percentual = 0.20;
  } else if (saldo <= 600) {
    percentual = 0.30;
  } else {
    percentual = 0.40;
  }

  const credito = saldo * percentual;

  resultado.innerHTML = `
    Saldo médio: R$ ${saldo.toFixed(2)}<br>
    Crédito concedido: R$ ${credito.toFixed(2)}
  `;
});