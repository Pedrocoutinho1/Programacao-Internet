let campoCodigo = document.querySelector("#campoCodigo");
let campoQuantidade = document.querySelector("#campoQuantidade");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado")

botao.addEventListener("click", function() {
  let codigo = parseFloat(campoCodigo.value.replace(",","."));
  let quantidade = parseFloat(campoQuantidade.value.replace(",","."));
  if (isNaN(codigo) || isNaN(quantidade)) { resultado.innerHTML = "Porfavor, coloque um valor num&eacute;rico, e um c&oacute;digo v&aacute;lido.";
    return;
}
let valorCodigo = 1;
let valorQuantidade = 1;

let nomeProduto = "";
let preco = 0;

if (codigo === 1) {
    nomeProduto = "Cachorro-Quente";
    preco = 11.00;
} else if (codigo === 2) {
    nomeProduto = "Bauru";
    preco = 8.50;
} else if (codigo === 3) {
    nomeProduto = "Misto Quente";
    preco = 8.00;
} else if (codigo === 4) {
    nomeProduto = "Hamburguer";
    preco = 9.00;
} else if (codigo === 5) {
    nomeProduto = "Cheeseburger";
    preco = 10.00;
} else if (codigo === 6) {
    nomeProduto = "Refrigerante";
    preco = 4.50;
} else {
    resultado.innerHTML = "C&oacute;digo inv&aacute;lido.";
}

if (preco > 0) {
    let total = preco * quantidade;
    resultado.innerHTML = `<b>${nomeProduto}</b><br>Valor Total a pagar: R$ ${total.toFixed(2)}`;
}
});