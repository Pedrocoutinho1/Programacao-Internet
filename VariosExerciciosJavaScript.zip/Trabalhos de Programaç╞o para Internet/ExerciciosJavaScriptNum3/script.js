let saldo = document.querySelector("#saldo");
let botao = document.querySelector("#btReajustar");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let saldoAtual = parseFloat(saldo.value.replace(",","."));
    if (isNaN(saldoAtual)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }
    let saldoReajustado = saldoAtual * 1.01;
    resultado.textContent = "Saldo com reajuste: R$ " + saldoReajustado.toFixed(2);
});