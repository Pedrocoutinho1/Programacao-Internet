let campoPessoas = document.querySelector("#campoPessoas");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = Number(campoPessoas.value);
    if (isNaN(n1)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let ovos = n1 * 2;
        let queijo = n1 * 50;

        resultado.innerHTML = "Quantidade de ovos: " + ovos + "<br>" + 
        "Gramas de queijo: " + queijo + " g";
    });