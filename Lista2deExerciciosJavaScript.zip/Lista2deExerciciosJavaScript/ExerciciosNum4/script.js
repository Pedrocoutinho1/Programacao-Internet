let quei = document.querySelector("#queijo");
let cal = document.querySelector("#calabresa");
let fran = document.querySelector("#frango");
let bac = document.querySelector("#bacon");
let refri = document.querySelector("#refrigerante");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let queijo = Number(quei.value);
    let calabresa = Number(cal.value);
    let frango = Number(fran.value)
    let bacon = Number(bac.value);
    let refrigerante = Number(refri.value);
    if (isNaN(queijo) || isNaN(calabresa) || isNaN(frango) || isNaN(bacon) || isNaN(refrigerante) ) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let queijoValor = queijo * 12.00;
        let calabresaValor = calabresa * 12.00;
        let frangoValor = frango * 12.00;
        let baconValor = bacon * 12.00;
        let refrigeranteValor = refrigerante * 7.00;
        let soma = queijoValor + calabresaValor + frangoValor + baconValor + refrigeranteValor;
      


        resultado.innerHTML = "Sabor Queijo: " + queijo + "<br>" +
        "Sabor Calabresa: " + calabresa + "<br>" +
        "Sabor Frango: " + frango + "<br>" +
        "Sabor Bacon: " + bacon + "<br>" +
        "Refrigerante: " + refrigerante + "<br>" +
        "Valor Total: R$ " + soma.toFixed(2);

    });