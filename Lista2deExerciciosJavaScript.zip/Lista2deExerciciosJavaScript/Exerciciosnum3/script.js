let Numero1 = document.querySelector("#Numero1");
let Numero2 = document.querySelector("#Numero2");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = Number(Numero1.value);
    let n2 = Number(Numero1.value);
    if (isNaN(n1) || isNaN(n2)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let soma = n1 + n2;
        let sub = n1 - n2;
        let multi = n1 * n2;
        let divs = n1 / n2;


        resultado.innerHTML = "Soma: " + soma + "<br>" + "Subtra&ccedil;&atilde;o: " +
        sub + "<br>" + "multiplica&ccedil;&atilde;o: " + multi + "<br>" + "divis&atilde;o: " +
        divs;

    });