let campoDolar = document.querySelector("#campoDolar")
let botao = document.querySelector("#btCalcular")
let resultado = document.querySelector("#resultado")

botao.addEventListener("click", function() {
    let n1 = parseFloat(campoDolar.value.replace(",","."));
    if (isNaN(campoDolar)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let aumento1 = n1 * 1.01;
        let aumento2 = n1 * 2.01;
        let aumento5 = n1 * 5.01;
        let aumento10 = n1 * 10.01;

        resultado.textContent.innerHTML = "Aumento em 1%: R$ " + aumento1.toFixed(2) + "<br>" +
        "Aumento em 2%: R$ " + aumento2.toFixed(2) + "<br>" +
        "Aumento em 5%: R$ " + aumento5.toFixed(2) + "<br>" +
        "Aumento em 10%: R$ " + aumento10.toFixed(2);

    });