let campoDolar = document.querySelector("#campoDolar");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = parseFloat(campoDolar.value.replace(",","."));
    if (isNaN(n1)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let aumento1 = n1 * 1.01;
        let aumento2 = n1 * 1.02;
        let aumento5 = n1 * 1.05;
        let aumento10 = n1 * 1.10;

        resultado.innerHTML = "Aumento em 1%: US$ " + aumento1.toFixed(2) + "<br>" +
        "Aumento em 2%: US$ " + aumento2.toFixed(2) + "<br>" +
        "Aumento em 5%: US$ " + aumento5.toFixed(2) + "<br>" +
        "Aumento em 10%: US$ " + aumento10.toFixed(2);

    });