let campoPrecoGasolina = document.querySelector("#campoPrecoGasolina");
let campoValor = document.querySelector("#campoValor");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = parseFloat(campoPrecoGasolina.value.replace(",","."));
    let n2 = parseFloat(campoValor.value.replace(",","."));
    if (isNaN(n1) || isNaN(n2)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let litros = n2 / n1;

        resultado.innerHTML = "<br>" + "Quantidade de litros: " + litros + " L";

    });