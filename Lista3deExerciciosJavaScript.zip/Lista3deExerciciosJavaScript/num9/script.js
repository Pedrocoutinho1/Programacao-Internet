let campoX = document.querySelector("#campoX");
let campoY = document.querySelector("#campoY");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = parseFloat(campoX.value.replace(",","."));
    let n2 = parseFloat(campoY.value.replace(",","."));
    if (isNaN(n1) || isNaN(n2)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let quantidadeCamisetas = P + M + G;

        resultado.innerHTML = "<br>" + "Quantidade de Camisetas Compradas: " + quantidadeCamisetas + "<br>" + "<br>"
        + "Valor Total: " + "<b>" + valorTotal.toFixed(2) + "</b>";
    });