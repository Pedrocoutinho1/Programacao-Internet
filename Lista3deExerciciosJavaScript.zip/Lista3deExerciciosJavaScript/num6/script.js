let campoPeso = document.querySelector("#campoPeso");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = parseFloat(campoPeso.value.replace(",","."));
    if (isNaN(n1)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let valor = n1 * 12.00;

        resultado.innerHTML = "<br>" + "Valor a pagar: R$ " + valor.toFixed(2) ;

    });