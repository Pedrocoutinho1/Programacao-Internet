let campoP = document.querySelector("#campoP");
let campoM = document.querySelector("#campoM");
let campoG = document.querySelector("#campoG");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let P = parseFloat(campoP.value.replace(",","."));
    let M = parseFloat(campoM.value.replace(",","."));
    let G = parseFloat(campoG.value.replace(",","."));
    if (isNaN(P) || isNaN(M) || isNaN(G)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let quantidadeCamisetas = P + M + G;
        let quantP = P * 10.00;
        let quantM = M * 12.00;
        let quantG = G * 15.00;
        let valorTotal = quantP + quantM + quantG;

        resultado.innerHTML = "<br>" + "Quantidade de Camisetas Compradas: " + quantidadeCamisetas + "<br>" + "<br>"
        + "Valor Total: " + "<b>" + valorTotal.toFixed(2) + "</b>";
    });