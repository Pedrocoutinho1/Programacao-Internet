let campoDia = document.querySelector("#campoDia");
let campoMes = document.querySelector("#campoMes");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let dia = parseFloat(campoDia.value.replace(",","."));
    let mes = parseFloat(campoMes.value.replace(",","."));
    if (isNaN(dia) || isNaN(mes)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let valor = dia < 1 || dia > 30 || mes < 1 || mes > 12;

        resultado.innerHTML = "<br>" + "Quantidade de dias passados: " + valor;
    });