let campoDia = document.querySelector("#campoDia");
let campoMes = document.querySelector("#campoMes");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let dia = parseFloat(campoDia.value.replace(",","."));
    let mes = parseFloat(campoMes.value.replace(",","."));
    if (isNaN(dia) || isNaN(mes)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let valor = (mes - 1) * 30 + dia + 10 

        resultado.innerHTML = "<br>" + "Quantidade de dias passados: " + valor;
    });