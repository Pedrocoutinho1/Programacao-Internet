let campoUm = document.querySelector("#campoUm");
let campoDois = document.querySelector("#campoDois");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = parseFloat(campoUm.value.replace(",","."));
    let n2 = parseFloat(campoDois.value.replace(",","."));
    if (isNaN(n1) || isNaN(n2)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let area = n1 * n2;

        resultado.innerHTML = "&Aacute;rea: " + area + "m";

    });