const campoX1 = document.querySelector("#campoX1");
const campoX2 = document.querySelector("#campoX2");
const campoY1 = document.querySelector("#campoY1");
const campoY2 = document.querySelector("#campoY2");
const botao = document.querySelector("#btCalcular");
const resultado = document.querySelector("#resultado");

botao.addEventListener("click", () => {
    const x1 = parseFloat(campoX1.value);
    const x2 = parseFloat(campoX2.value);
    const y1 = parseFloat(campoY1.value);
    const y2 = parseFloat(campoY2.value);
    if (isNaN(x1) || isNaN(x2) || isNaN(y1) || isNaN(y2)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

       
            const dx = x2 - x1;
            const dy = y2 - y1;
            const distancia = Math.sqrt(dx * dx + dy * dy);
    

        resultado.innerHTML = "<br>" + "Dist&acirc;ncia: " + distancia.toFixed(2) ;
    });