let campoPao = document.querySelector("#campoPao");
let campoBroa = document.querySelector("#campoBroa");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = parseFloat(campoPao.value.replace(",","."));
    let n2 = parseFloat(campoBroa.value.replace(",","."));
    if (isNaN(n1) || isNaN(n2)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let venda1 = n1 * 0.12;
        let venda2 = n2 * 1.50;
        let totalVendas = venda1 + venda2;

        let poupanca = totalVendas * 0.10;

        resultado.innerHTML = "Venda total de p&atilde;es: R$ " + venda1.toFixed(2) + "<br>"
        + "Venda total de broas: R$ " + venda2.toFixed(2) + "<br>" + "<br>"
        + "Total Arrecadado: R$ " + totalVendas.toFixed(2) + "<br>" + "<br>" + "-------------------" +  "<br>" + "<br>"
        +  "Valor de 10% do total na poupan&ccedil;a: " + "<br>" + "R$ " + poupanca.toFixed(2);

    });