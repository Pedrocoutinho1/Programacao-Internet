let campoHorse = document.querySelector("#campoHorse");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = parseFloat(campoHorse.value.replace(",","."));
    if (isNaN(n1)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let ferraduras = n1 * 4;

        resultado.innerHTML = "Quantidade de Ferraduras: " + ferraduras;

    });