let campoDias = document.querySelector("#campoDias");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = Number(campoDias.value);
    if (isNaN(n1)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

    let dias = n1;
    let anos = Math.floor(dias / 365);
    let restoDias = dias % 365;
    let meses = Math.floor(restoDias / 30);
    let diasRestantes = restoDias % 30;

        resultado.innerHTML = "<br>" + "Anos: " + anos + 
        "<br>" + "<br>" + "meses: " + meses +
        "<br>" + "<br>" + "dias sem acidentes: " + diasRestantes;
    });