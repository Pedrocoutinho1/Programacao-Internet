let nome = document.querySelector("#campoNome");
let campoIdade = document.querySelector("#campoIdade");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = Number(campoIdade.value);
    if (isNaN(n1)) { resultado.textContent = "Por favor, insira um valor numerico valido.";
        return;
    }

        let dias = n1 * 365;

        resultado.innerHTML = nome.value + ", voc&ecirc; j&aacute; viveu " + "<b>" + dias + "</b>" + " dias.";
    });