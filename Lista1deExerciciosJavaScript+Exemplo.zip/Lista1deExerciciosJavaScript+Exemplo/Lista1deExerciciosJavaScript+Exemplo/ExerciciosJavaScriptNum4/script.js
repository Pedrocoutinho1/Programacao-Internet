let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let numero3 = document.querySelector("#numero3");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let n1 = parseFloat(numero1.value.replace(",","."));
    let n2 = parseFloat(numero2.value.replace(",","."));
    let n3 = parseFloat(numero3.value.replace(",","."));

    if (isNaN(n1) || isNaN(n2) || isNaN(n3)) { 
        resultado.textContent = "Por favor, preencha os 3 numeros corretamente.";
        return;
    }

    let mediaAritmetica = (n1 + n2 + n3) / 3;
    let mediaPonderada = (n1 * 3 + n2 * 2 + n3 * 5) / 10;
    let somaMedias = mediaAritmetica + mediaPonderada;
    let mediaDasMedias = somaMedias / 2;

    resultado.innerHTML = "M&eacute;dia Aritm&eacute;tica: " + mediaAritmetica + "<br>" + 
    "M&eacute;dia Ponderada: " + mediaPonderada + "<br>" +
    "Soma M&eacute;dias: " + somaMedias + "<br>" +
    "M&eacute;dia das M&eacute;dias: " + mediaDasMedias;
});