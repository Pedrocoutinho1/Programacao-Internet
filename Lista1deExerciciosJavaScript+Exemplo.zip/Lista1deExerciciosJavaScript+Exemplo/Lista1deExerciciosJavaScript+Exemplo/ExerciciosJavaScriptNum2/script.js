let valorKG = document.querySelector("#valorKG");
let QuantidadeKGProduto = document.querySelector("#QuantidadeKGProduto");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#Resultado");

botao.addEventListener("click",
function() {

    let precoPorKG = parseFloat(valorKG.value.replace(",","."));
    let quantidade = parseFloat(QuantidadeKGProduto.value.replace(",","."));
    if (isNaN(precoPorKG) ||isNaN(quantidade)) {
        resultado.textContent = "Preencha corretamente o valor do Kg e a quantidade.";
        return;
    }

    let total = precoPorKG * quantidade;
    resultado.textContent = "Valor total a pagar: R$ " + total.toFixed(2);
});