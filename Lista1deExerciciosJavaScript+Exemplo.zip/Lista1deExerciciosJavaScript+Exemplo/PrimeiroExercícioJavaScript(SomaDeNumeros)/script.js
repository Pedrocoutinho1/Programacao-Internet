
let campoPrimeiro = document.querySelector("#campoPrimeiro");
let campoSegundo = document.querySelector("#campoSegundo");
let btSomar = document.querySelector("#btSomar");
let resultado = document.querySelector("#resultado");

function somarNumeros(){

    let num1 = Number(campoPrimeiro.value);
    let num2 = Number(campoSegundo.value);

    resultado.textContent = (num1 + num2);
}

btSomar.onclick = function(){
    somarNumeros();
}

