let valorKG = document.querySelector("valorKG");
let QuantidadeKGProduto = document.querySelector("QuantidadeKGProduto");
let botao = document.querySelector("btCalcular");
let resultado = document.querySelector("Resultado");

function.