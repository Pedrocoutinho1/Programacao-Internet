let botao = document.querySelector("btCalcular");
let campoValorPago = document.querySelector("valorPago");
let = campoPrecoProduto = document.querySelector("precoProduto");
let = campoResultado = document.querySelector("resultado");

botao.addEventListener("click",function() {
    let valorPago = parseFloat(campoValorPago.Value.replace(
        ",","."));
        let = precoProduto = parseFloat(campoPrecoProduto.Value.replace(
            ",","."));
            if (isNaN(valorPago) ||
            isNaN(precoProduto)) {
                campoResultado.textContent = "Por favor preencha os dois valores corretamente";
                return;
            }

            let troco = valorPago - precoProduto;

            if (troco < 0) {
                campoResultado.textContent = "Valor pago insuficiente";
            } else {
                campoResultad.textContent = "Troco: R$" + troco.toFixed(2);
            }
            });  

        
    
