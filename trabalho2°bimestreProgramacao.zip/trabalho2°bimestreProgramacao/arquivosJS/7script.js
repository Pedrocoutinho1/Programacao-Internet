let campoPreco = document.querySelector("#preco");
let campoCondicao = document.querySelector("#condicao");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function () {
  let precoTexto = campoPreco.value.trim().replace(",", ".");
  let condicao = campoCondicao.value.trim().toLowerCase();
  let preco = parseFloat(precoTexto);

  if (isNaN(preco) || preco <= 0) {
    resultado.innerHTML = "Por favor, insira um valor válido para o preço.";
    return;
  }

  if (condicao === "a") {
    let total = preco * 0.9;
    resultado.innerHTML = `Total a pagar: R$ ${total.toFixed(2).replace(".", ",")} (10% de desconto).`;
  } else if (condicao === "b") {
    let total = preco * 0.85;
    resultado.innerHTML = `Total a pagar: R$ ${total.toFixed(2).replace(".", ",")} (15% de desconto).`;
  } else if (condicao === "c") {
    let parcela = preco / 2;
    resultado.innerHTML = `Total a pagar: 2x de R$ ${parcela.toFixed(2).replace(".", ",")} (sem juros).`;
  } else if (condicao === "d") {
    let total = preco * 1.10;
    let parcela = total / 2;
    resultado.innerHTML = `Total a pagar: 2x de R$ ${parcela.toFixed(2).replace(".", ",")} (com 10% de juros). Total: R$ ${total.toFixed(2).replace(".", ",")}.`;
  } else {
    resultado.innerHTML = "Código inválido. Use a, b, c ou d.";
  }
});