let campoX = document.querySelector("#campoX");
let campoY = document.querySelector("#campoY");
let campoZ = document.querySelector("#campoZ");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let x = parseFloat(campoX.value.replace(",","."));
    let y = parseFloat(campoY.value.replace(",","."));
    let z = parseFloat(campoZ.value.replace(",","."));
    if (isNaN(x) || isNaN(y) || isNaN(z)) { resultado.innerHTML = "Por favor, insira um valor num&eacute;rico de tri&acirc;ngulo.";
        return;
    }

    if (x <= 0 || y <= 0 || z <= 0) {
    resultado.textContent = "Os comprimentos devem ser maiores que zero.";
    return;
  }

  if (x < y + z && y < x + z && z < x + y) {
    if (x === y && y === z) {
      resultado.innerHTML = "Tri&acirc;ngulo Equil&aacute;tero.";
    } else if (x === y || y === z || x === z) {
      resultado.innerHTML = "Tri&acirc;ngulo Is&oacute;sceles.";
    } else {
      resultado.innerHTML = "Tri&acirc;ngulo Escaleno.";
    }
  } else {
    resultado.innerHTML = "Os valores informados n&atilde;o formam um tri&acirc;ngulo.";
  }
    });