let campoNivel = document.querySelector("#nivel");
let campoHoras = document.querySelector("#horas");
let botao = document.querySelector("#btnCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function () {
  let nivel = campoNivel.value.trim();
  let horasTexto = campoHoras.value.trim().replace(",", ".");
  let horas = parseFloat(horasTexto);
  let valorHora = 0;

  if (isNaN(horas) || horas <= 0) {
    resultado.innerHTML = "Por favor, insira uma quantidade de horas v&aacute;lida.";
    return;
  }

  if (nivel === "1") {
    valorHora = 12.00;
  } else if (nivel === "2") {
    valorHora = 17.00;
  } else if (nivel === "3") {
    valorHora = 25.00;
  } else {
    resultado.innerHTML = "N&iacute;vel inv&aacute;lido. Use 1, 2 ou 3.";
    return;
  }

  let salario = valorHora * horas * 4.5;
  resultado.innerHTML = `Sal&aacute;rio do professor: R$ ${salario.toFixed(2).replace(".", ",")}`;
});