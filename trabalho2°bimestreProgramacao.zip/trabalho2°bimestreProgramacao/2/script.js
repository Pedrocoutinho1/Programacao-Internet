let campoAltura = document.querySelector("#campoAltura");
let campoPeso = document.querySelector("#campoPeso");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let altura = parseFloat(campoAltura.value.replace(",","."));
    let peso = parseFloat(campoPeso.value.replace(",","."));
    if (isNaN(altura) || isNaN(peso) || altura <= 0 || peso <= 0){ resultado.innerHTML = "Por favor, insira um valor num&eacute;rico v&aacute;lido.";
        return;
    }

    const imc = peso / (altura * altura);
  let classificacao = "";

  if (imc < 18.5) {
    classificacao = "Abaixo do peso";
  } else if (imc < 25) {
    classificacao = "Peso normal";
  } else if (imc < 30) {
    classificacao = "Sobrepeso";
  } else if (imc < 35) {
    classificacao = "Obesidade grau 1";
  } else if (imc < 40) {
    classificacao = "Obesidade grau 2";
  } else {
    classificacao = "Obesidade grau 3";
  }

  resultado.textContent = `IMC: ${imc.toFixed(2)} - ${classificacao}`;
}
);