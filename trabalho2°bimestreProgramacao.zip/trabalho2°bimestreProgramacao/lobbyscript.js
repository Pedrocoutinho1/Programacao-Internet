function toggle(numero) {
  const enunciado = document.getElementById("enunciado" + numero);
  const todos = document.querySelectorAll(".enunciado");

  // Fecha todos os outros
  todos.forEach(function(div) {
    if (div !== enunciado) div.style.display = "none";
  });

  // Alterna visibilidade do clicado
  if (enunciado.style.display === "block") {
    enunciado.style.display = "none";
  } else {
    enunciado.style.display = "block";
  }
}
