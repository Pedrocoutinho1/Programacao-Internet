let campoSalario = document.querySelector("#campoSalario");
let campoCodigo = document.querySelector("#campoCodigo");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

botao.addEventListener("click", function() {
    let salario = parseFloat(campoSalario.value.replace(",","."));
    let codigo = parseFloat(campoCodigo.value.replace(",","."));
    if (isNaN(salario) || isNaN(codigo) || salario <= 0){ resultado.innerHTML = "Por favor, insira um sal&aacute;rio v&aacute;lido e c&oacute;digo de cargo.";
        return;
    }

     let percentual;
  switch (codigo) {
    case 101:
      percentual = 0.10;
      break;
    case 102:
      percentual = 0.20;
      break;
    case 103:
      percentual = 0.30;
      break;
    default:
      resultado.innerHTML = "C&oacute;digo de cargo inv&aacute;lido. Use 101, 102 ou 103.";
      return;
  }

  const aumento = salario * percentual;
  const novoSalario = salario + aumento;

  resultado.innerHTML = `
    Sal&aacute;rio antigo: R$ ${salario.toFixed(2)}<br>
    Novo sal&aacute;rio: R$ ${novoSalario.toFixed(2)}<br>
    Diferen&ccedil;a: R$ ${aumento.toFixed(2)}
  `;
});