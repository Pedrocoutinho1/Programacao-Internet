function calcularTotal() {
  const codigo = parseInt(document.getElementById("codigo").value);
  const quantidade = parseInt(document.getElementById("quantidade").value);
  const resultado = document.getElementById("resultado");

  const cardapio = {
    1: { nome: "Cachorro Quente", preco: 11.00 },
    2: { nome: "Bauru", preco: 8.50 },
    3: { nome: "Misto Quente", preco: 8.00 },
    4: { nome: "Hamburger", preco: 9.00 },
    5: { nome: "Cheeseburger", preco: 10.00 },
    6: { nome: "Refrigerante", preco: 4.50 }
  };

  if (!cardapio[codigo] || isNaN(quantidade) || quantidade <= 0) {
    resultado.textContent = "Código ou quantidade inválidos.";
    return;
  }

  const item = cardapio[codigo];
  const total = item.preco * quantidade;

  resultado.innerHTML = `
    Produto: ${item.nome}<br>
    Quantidade: ${quantidade}<br>
    Total a pagar: R$ ${total.toFixed(2)}
  `;
}
